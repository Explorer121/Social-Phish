from django.contrib import admin
from .models import Meter
# Register your models here.

admin.site.register(Meter)
