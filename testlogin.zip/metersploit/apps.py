from django.apps import AppConfig


class MetersploitConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'metersploit'
