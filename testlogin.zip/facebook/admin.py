from django.contrib import admin
from facebook.models import Facebook_Account
# Register your models here.
admin.site.register(Facebook_Account)
