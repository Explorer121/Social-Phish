# Google Login Page CSS
I made google login page using html and css. Let me know if I missed any details.

# Live Demo
https://google-login-nemo.glitch.me


# Notes
- The Login isnt functional
- ((( I didn't make this website for phishing))) 
- Disocrd: Nemo#1819
