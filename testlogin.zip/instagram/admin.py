from django.contrib import admin
from instagram.models import Instagram_Account
# Register your models here.
admin.site.register(Instagram_Account)
