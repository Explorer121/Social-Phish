from django.contrib import admin
from discord.models import Discord_Account
# Register your models here.
admin.site.register(Discord_Account)
