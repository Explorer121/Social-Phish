from django.apps import AppConfig


class WebmailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webmail'
