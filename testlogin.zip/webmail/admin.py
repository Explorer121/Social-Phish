from django.contrib import admin

# Register your models here.
from webmail.models import Webmail

admin.site.register(Webmail)