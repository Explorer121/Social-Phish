# Google login page clone

## My clone

![My clone](./images/my-clone.png)

## Original page

![Original page](./images/google-login-page.png)
